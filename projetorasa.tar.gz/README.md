# demo-Rasa-Bot
Usando Rasa Bot
[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/Graziele-Rodrigues/demo-Rasa-Bot/HEAD)
